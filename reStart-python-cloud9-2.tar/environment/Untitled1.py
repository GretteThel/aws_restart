#Store the human preproinsulin sequence in a variable called prepoinsulin
preproinsulin=
"Store the remaining sequence element of human insulin in variables name isInsulin, bInsulin, aInsulin,cInsulin
isInsulin=""
bInsulin=""
aInsulin=""
cInsulin=""
insulin=bInsulin + aInsulin
print(insulin)

